import time
from datetime import datetime

from analytics.indicators import Indicators
from core.price_buffer import PriceBuffer
from execution.paper_trader import PaperTrader
from risk.risk_engine import RiskEngine
from strategies.simple_strategy import generate_signal


class TradingEngine:

    def __init__(self):
        self.buffer = PriceBuffer()
        self.indicators = Indicators()
        self.risk = RiskEngine()
        self.trader = PaperTrader()

        self.last_signal = None
        self.last_notification = None
        self.notification_interval = 15 * 60  # 15 minutes


    def update(self, price):

        # Store incoming market price
        self.buffer.add(price)

        prices = self.buffer.get_prices()


        # Calculate indicators
        sma = self.indicators.sma(prices)
        ema = self.indicators.ema(prices)
        volatility = self.indicators.volatility(prices)


        market_data = {
            "price": price,
            "sma": sma,
            "ema": ema,
            "volatility": volatility,
            "timestamp": datetime.utcnow().isoformat()
        }


        # Generate trading decision
        signal = generate_signal(market_data)

        action = "HOLD"


        portfolio = self.trader.get_portfolio()


        # Risk-controlled execution
        if signal == "BUY":

            if self.risk.allow_trade(
                market_data,
                portfolio
            ):
                self.trader.buy(price)
                action = "OPEN_LONG"


        elif signal == "SELL":

            if self.risk.allow_trade(
                market_data,
                portfolio
            ):
                self.trader.sell(price)
                action = "OPEN_SHORT"


        # Refresh portfolio after execution
        portfolio = self.trader.get_portfolio()


        # Notification timing control
        current_time = time.time()

        send_notification = False


        if (
            self.last_notification is None
            or current_time - self.last_notification >= self.notification_interval
        ):
            send_notification = True
            self.last_notification = current_time


        return {
            "price": price,
            "signal": signal,
            "action": action,
            "sma": sma,
            "ema": ema,
            "volatility": volatility,
            "portfolio": portfolio,
            "send_notification": send_notification
        }
